@echo off
setlocal EnableExtensions

set "MANIFEST_URL=https://raw.githubusercontent.com/MrTechno84/kasstroom-update/main/version.json"

cd /d "%~dp0"

where powershell >nul 2>nul
if errorlevel 1 (
  echo PowerShell is niet gevonden.
  echo Deze updater heeft PowerShell nodig om de release ZIP te downloaden en uit te pakken.
  pause
  exit /b 1
)

echo Kasstroom release-update voorbereiden...
echo.
echo Wat gaat er gebeuren?
echo - De nieuwste versie wordt opgezocht via het publieke updatebestand.
echo - De GitHub release ZIP wordt gedownload.
echo - De ZIP wordt uitgepakt in een tijdelijke map.
echo - De app-bestanden in deze map worden vervangen.
echo - Je dashboarddata blijft normaal bewaard in de browser.
echo.
choice /C JN /M "Doorgaan"
if errorlevel 2 (
  echo Update geannuleerd.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference = 'Stop';" ^
  "$manifestUrl = '%MANIFEST_URL%';" ^
  "$appDir = (Get-Location).Path;" ^
  "$manifest = Invoke-RestMethod -Uri $manifestUrl -UseBasicParsing;" ^
  "$version = [string]$manifest.version;" ^
  "if ([string]::IsNullOrWhiteSpace($version)) { throw 'Geen versie gevonden in het updatebestand.' }" ^
  "$downloadUrl = [string]$manifest.downloadUrl;" ^
  "if ([string]::IsNullOrWhiteSpace($downloadUrl)) { $downloadUrl = 'https://github.com/MrTechno84/kasstroom/archive/refs/tags/v' + $version + '.zip' }" ^
  "$tempRoot = Join-Path $env:TEMP ('kasstroom-update-' + [guid]::NewGuid().ToString('N'));" ^
  "$zipPath = Join-Path $tempRoot 'kasstroom.zip';" ^
  "$extractDir = Join-Path $tempRoot 'extract';" ^
  "New-Item -ItemType Directory -Path $tempRoot, $extractDir | Out-Null;" ^
  "Write-Host ('Downloaden: ' + $downloadUrl);" ^
  "Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath -UseBasicParsing;" ^
  "Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force;" ^
  "$sourceDir = Get-ChildItem -LiteralPath $extractDir -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'index.html') } | Select-Object -First 1;" ^
  "if (-not $sourceDir) { throw 'Geen geldige app-map gevonden in de ZIP.' }" ^
  "$exclude = @('.git', '.github', 'server.err', 'server.out');" ^
  "Get-ChildItem -LiteralPath $sourceDir.FullName -Force | Where-Object { $exclude -notcontains $_.Name } | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $appDir -Recurse -Force };" ^
  "Remove-Item -LiteralPath $tempRoot -Recurse -Force;" ^
  "Write-Host ('Update naar versie ' + $version + ' is klaar.');"

if errorlevel 1 goto update_failed

echo.
echo Update klaar. Herstart de app of refresh de browser.
pause
exit /b 0

:update_failed
echo.
echo Update mislukt.
echo Controleer of:
echo - je internetverbinding werkt
echo - de GitHub release ZIP bereikbaar is
echo - deze map schrijfbaar is
echo - de release als ZIP beschikbaar is voor deze gebruiker
pause
exit /b 1
