const months = [
  "Januari",
  "Februari",
  "Maart",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Augustus",
  "September",
  "Oktober",
  "November",
  "December",
];

const APP_VERSION = "1.0.0.6";
const UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/MrTechno84/kasstroom-update/main/version.json";
let availableUpdateVersion = null;
const STORAGE_KEY = "financeDashboardDataClean";
const THEME_KEY = "financeDashboardAccent";
const SECONDARY_ACCENT_KEY = "financeDashboardSecondaryAccent";
const BACKGROUND_KEY = "financeDashboardBackground";
const TEXT_KEY = "financeDashboardText";
const BUTTON_TEXT_KEY = "financeDashboardButtonText";
const FONT_KEY = "financeDashboardFont";
const SAVING_TARGET_KEY = "financeDashboardSavingTarget";
const LANGUAGE_KEY = "financeDashboardLanguage";
const CURRENCY_KEY = "financeDashboardCurrency";
const BACKUP_KEY = "financeDashboardBackup";
const defaultCategories = [
  "Salaris",
  "Wonen",
  "Boodschappen",
  "Vervoer",
  "Verzekeringen",
  "Vrije tijd",
  "Abonnementen",
  "Gezondheid",
  "Overig",
];
const defaultData = createEmptyData();

const translations = {
  "nl-BE": {
    overview: "Overzicht",
    chart: "Grafiek",
    categories: "Categorieen",
    months: "Maanden",
    year: "Jaar",
    savingTarget: "Doel spaarratio",
    theme: "Thema",
    settings: "Instellingen",
    accentColor: "Accentkleur",
    secondaryAccentColor: "Tweede accentkleur",
    background: "Achtergrond",
    textColor: "Tekstkleur",
    buttonText: "Knoptekst",
    font: "Lettertype",
    language: "Taal",
    currency: "Valuta",
    yearlyMonthly: "Maandbasis per jaar",
    incomeExpenseTitle: "Inkomsten en uitgaven",
    income: "Inkomsten",
    expense: "Uitgaven",
    balance: "Saldo",
    savingRate: "Spaarratio",
    trend: "Trend",
    monthlyCashflow: "Maandelijkse kasstroom",
    distribution: "Verdeling",
    expenseMix: "Uitgavenmix",
    bestMonth: "Beste maand",
    monthChart: "Maandgrafiek",
    manageCategories: "Beheer categorieen",
    newCategory: "Nieuwe categorie",
    editData: "Data bewerken",
    addTransaction: "Voeg transactie toe",
    fromMonth: "Van maand",
    toMonth: "Tot maand",
    type: "Type",
    category: "Categorie",
    amount: "Bedrag",
    note: "Notitie",
    add: "Toevoegen",
    detail: "Detail",
    monthOverview: "Maandoverzicht",
    monthDetail: "Maanddetail",
    month: "Maand",
    actions: "Acties",
    actionsManage: "Beheer",
    selectMonth: "Selecteer een maand",
    incomeType: "Inkomst",
    expenseType: "Uitgave",
    aboveTarget: "Boven doel",
    belowTarget: "Onder doel",
    newYear: "Nieuw jaar",
    noTransactions: "Geen transacties voor deze maand.",
    noTransactionsChart: "Geen transacties voor deze maand",
    bestMonthCopy: "{month} leverde het hoogste saldo op met {amount}.",
    notePlaceholder: "Bijv. auto, brandverzekering",
    newCategoryPlaceholder: "Bijv. abonnementen",
    editTransaction: "Transactie aanpassen",
    deleteTransaction: "Transactie verwijderen",
    saveTransaction: "Transactie opslaan",
    deletePeriod: "Periode verwijderen",
    deletePeriodHint: "Verwijder dezelfde transactie voor de gekozen maanden.",
    saveCategory: "Categorie opslaan",
    deleteCategory: "Categorie verwijderen",
    cancel: "Annuleren",
    save: "Opslaan",
    confirmReset: "Alle ingevoerde data wordt gewist. Wil je doorgaan?",
    deleteAll: "Verwijder alles",
    restoreBackup: "Backup terugzetten",
    noBackup: "Geen backup beschikbaar.",
    backupAvailable: "Backup beschikbaar van {date}.",
    backupCreated: "Backup gemaakt van {date}.",
    confirmRestoreBackup: "De huidige data wordt vervangen door de backup. Wil je doorgaan?",
    backupRestored: "Backup teruggezet.",
    version: "Versie",
    updateAvailable: "Update beschikbaar",
    updateAvailableBody: "Er staat versie {version} klaar. Gebruik update.bat om bij te werken.",
    updateAction: "Update",
    updateInstructions: "De app kan update.bat niet zelf starten. update.bat staat in dezelfde map als deze app.\n\nAls je doorgaat, kopieer ik .\\update.bat naar je klembord.\n\nDaarna open je de app-map en dubbelklik je update.bat. Het script downloadt de nieuwste GitHub release ZIP, pakt die uit en vervangt de app-bestanden. Je ingevoerde dashboarddata blijft bewaard in deze browser.\n\nDoorgaan?",
    updateCommandCopied: "Updatecommando gekopieerd",
    updateCommandCopiedBody: "Dubbelklik update.bat in de app-map om de release ZIP te downloaden en te installeren.",
    updateCommandPrompt: "Kopieer dit commando en voer het uit in de app-map:",
    noUpdate: "Je gebruikt de nieuwste versie.",
    exportCsv: "Exporteer CSV",
    sidebarNavigation: "Dashboard navigatie",
    sections: "Secties",
    selectYear: "Selecteer jaar",
    metrics: "Kerncijfers",
    cashflowChartLabel: "Grafiek inkomsten, uitgaven en saldo per maand",
    monthDetailChartLabel: "Grafiek transacties voor geselecteerde maand",
    categoryList: "Categorieen",
    editCategoryName: "Categorie {category}",
    categoryNames: {
      Salaris: "Salaris",
      Wonen: "Wonen",
      Boodschappen: "Boodschappen",
      Vervoer: "Vervoer",
      Verzekeringen: "Verzekeringen",
      "Vrije tijd": "Vrije tijd",
      Abonnementen: "Abonnementen",
      Gezondheid: "Gezondheid",
      Overig: "Overig",
    },
  },
  "en-US": {
    overview: "Overview",
    chart: "Chart",
    categories: "Categories",
    months: "Months",
    year: "Year",
    savingTarget: "Savings target",
    theme: "Theme",
    settings: "Settings",
    accentColor: "Accent color",
    secondaryAccentColor: "Second accent color",
    background: "Background",
    textColor: "Text color",
    buttonText: "Button text",
    font: "Font",
    language: "Language",
    currency: "Currency",
    yearlyMonthly: "Monthly by year",
    incomeExpenseTitle: "Income and expenses",
    income: "Income",
    expense: "Expenses",
    balance: "Balance",
    savingRate: "Savings rate",
    trend: "Trend",
    monthlyCashflow: "Monthly cash flow",
    distribution: "Distribution",
    expenseMix: "Expense mix",
    bestMonth: "Best month",
    monthChart: "Month chart",
    manageCategories: "Manage categories",
    newCategory: "New category",
    editData: "Edit data",
    addTransaction: "Add transaction",
    fromMonth: "From month",
    toMonth: "To month",
    type: "Type",
    category: "Category",
    amount: "Amount",
    note: "Note",
    add: "Add",
    detail: "Detail",
    monthOverview: "Monthly overview",
    monthDetail: "Month detail",
    month: "Month",
    actions: "Actions",
    actionsManage: "Manage",
    selectMonth: "Select a month",
    incomeType: "Income",
    expenseType: "Expense",
    aboveTarget: "Above target",
    belowTarget: "Below target",
    newYear: "New year",
    noTransactions: "No transactions for this month.",
    noTransactionsChart: "No transactions for this month",
    bestMonthCopy: "{month} had the highest balance at {amount}.",
    notePlaceholder: "E.g. car, fire insurance",
    newCategoryPlaceholder: "E.g. subscriptions",
    editTransaction: "Edit transaction",
    deleteTransaction: "Delete transaction",
    saveTransaction: "Save transaction",
    deletePeriod: "Delete period",
    deletePeriodHint: "Delete the same transaction for the selected months.",
    saveCategory: "Save category",
    deleteCategory: "Delete category",
    cancel: "Cancel",
    save: "Save",
    confirmReset: "All entered data will be deleted. Do you want to continue?",
    deleteAll: "Delete everything",
    restoreBackup: "Restore backup",
    noBackup: "No backup available.",
    backupAvailable: "Backup available from {date}.",
    backupCreated: "Backup created from {date}.",
    confirmRestoreBackup: "Current data will be replaced by the backup. Do you want to continue?",
    backupRestored: "Backup restored.",
    version: "Version",
    updateAvailable: "Update available",
    updateAvailableBody: "Version {version} is available. Use update.bat to update.",
    updateAction: "Update",
    updateInstructions: "The app cannot start update.bat by itself. update.bat is in the same folder as this app.\n\nIf you continue, I will copy .\\update.bat to your clipboard.\n\nThen open the app folder and double-click update.bat. The script downloads the newest GitHub release ZIP, extracts it, and replaces the app files. Your entered dashboard data stays saved in this browser.\n\nContinue?",
    updateCommandCopied: "Update command copied",
    updateCommandCopiedBody: "Double-click update.bat in the app folder to download and install the release ZIP.",
    updateCommandPrompt: "Copy this command and run it in the app folder:",
    noUpdate: "You are using the latest version.",
    exportCsv: "Export CSV",
    sidebarNavigation: "Dashboard navigation",
    sections: "Sections",
    selectYear: "Select year",
    metrics: "Key figures",
    cashflowChartLabel: "Chart of income, expenses and balance by month",
    monthDetailChartLabel: "Chart of transactions for the selected month",
    categoryList: "Categories",
    editCategoryName: "Category {category}",
    categoryNames: {
      Salaris: "Salary",
      Wonen: "Housing",
      Boodschappen: "Groceries",
      Vervoer: "Transport",
      Verzekeringen: "Insurance",
      "Vrije tijd": "Leisure",
      Abonnementen: "Subscriptions",
      Gezondheid: "Health",
      Overig: "Other",
    },
  },
  "fr-BE": {
    overview: "Apercu",
    chart: "Graphique",
    categories: "Categories",
    months: "Mois",
    year: "Annee",
    savingTarget: "Objectif d'epargne",
    theme: "Theme",
    settings: "Parametres",
    accentColor: "Couleur d'accent",
    secondaryAccentColor: "Deuxieme accent",
    background: "Arriere-plan",
    textColor: "Couleur du texte",
    buttonText: "Texte des boutons",
    font: "Police",
    language: "Langue",
    currency: "Devise",
    yearlyMonthly: "Mensuel par annee",
    incomeExpenseTitle: "Revenus et depenses",
    income: "Revenus",
    expense: "Depenses",
    balance: "Solde",
    savingRate: "Taux d'epargne",
    trend: "Tendance",
    monthlyCashflow: "Flux mensuel",
    distribution: "Repartition",
    expenseMix: "Mix des depenses",
    bestMonth: "Meilleur mois",
    monthChart: "Graphique du mois",
    manageCategories: "Gerer les categories",
    newCategory: "Nouvelle categorie",
    editData: "Modifier les donnees",
    addTransaction: "Ajouter une transaction",
    fromMonth: "Du mois",
    toMonth: "Au mois",
    type: "Type",
    category: "Categorie",
    amount: "Montant",
    note: "Note",
    add: "Ajouter",
    detail: "Detail",
    monthOverview: "Apercu mensuel",
    monthDetail: "Detail du mois",
    month: "Mois",
    actions: "Actions",
    actionsManage: "Gerer",
    selectMonth: "Selectionnez un mois",
    incomeType: "Revenu",
    expenseType: "Depense",
    aboveTarget: "Au-dessus de l'objectif",
    belowTarget: "Sous l'objectif",
    newYear: "Nouvelle annee",
    noTransactions: "Aucune transaction pour ce mois.",
    noTransactionsChart: "Aucune transaction pour ce mois",
    bestMonthCopy: "{month} a le solde le plus eleve avec {amount}.",
    notePlaceholder: "Ex. voiture, assurance incendie",
    newCategoryPlaceholder: "Ex. abonnements",
    editTransaction: "Modifier la transaction",
    deleteTransaction: "Supprimer la transaction",
    saveTransaction: "Enregistrer la transaction",
    deletePeriod: "Supprimer la periode",
    deletePeriodHint: "Supprimer la meme transaction pour les mois selectionnes.",
    saveCategory: "Enregistrer la categorie",
    deleteCategory: "Supprimer la categorie",
    cancel: "Annuler",
    save: "Enregistrer",
    confirmReset: "Toutes les donnees saisies seront supprimees. Voulez-vous continuer ?",
    deleteAll: "Tout supprimer",
    restoreBackup: "Restaurer la sauvegarde",
    noBackup: "Aucune sauvegarde disponible.",
    backupAvailable: "Sauvegarde disponible du {date}.",
    backupCreated: "Sauvegarde creee le {date}.",
    confirmRestoreBackup: "Les donnees actuelles seront remplacees par la sauvegarde. Voulez-vous continuer ?",
    backupRestored: "Sauvegarde restauree.",
    version: "Version",
    updateAvailable: "Mise a jour disponible",
    updateAvailableBody: "La version {version} est disponible. Utilisez update.bat pour mettre a jour.",
    updateAction: "Mettre a jour",
    updateInstructions: "L'application ne peut pas lancer update.bat elle-meme. update.bat se trouve dans le meme dossier que cette application.\n\nSi vous continuez, je copie .\\update.bat dans le presse-papiers.\n\nEnsuite, ouvrez le dossier de l'application et double-cliquez sur update.bat. Le script telecharge la derniere release ZIP GitHub, l'extrait et remplace les fichiers de l'application. Vos donnees du tableau de bord restent enregistrees dans ce navigateur.\n\nContinuer ?",
    updateCommandCopied: "Commande de mise a jour copiee",
    updateCommandCopiedBody: "Double-cliquez sur update.bat dans le dossier de l'application pour telecharger et installer la release ZIP.",
    updateCommandPrompt: "Copiez cette commande et executez-la dans le dossier de l'application :",
    noUpdate: "Vous utilisez la derniere version.",
    exportCsv: "Exporter CSV",
    sidebarNavigation: "Navigation du tableau de bord",
    sections: "Sections",
    selectYear: "Selectionner l'annee",
    metrics: "Indicateurs",
    cashflowChartLabel: "Graphique des revenus, depenses et solde par mois",
    monthDetailChartLabel: "Graphique des transactions du mois selectionne",
    categoryList: "Categories",
    editCategoryName: "Categorie {category}",
    categoryNames: {
      Salaris: "Salaire",
      Wonen: "Logement",
      Boodschappen: "Courses",
      Vervoer: "Transport",
      Verzekeringen: "Assurances",
      "Vrije tijd": "Loisirs",
      Abonnementen: "Abonnements",
      Gezondheid: "Sante",
      Overig: "Autre",
    },
  },
};

let financeData = normalizeData(loadData());
let activeYear = String(new Date().getFullYear());
if (!financeData[activeYear]) activeYear = Object.keys(financeData).sort().at(-1);
let selectedMonth = new Date().getMonth();
let activeCategory = null;

let activeLocale = localStorage.getItem(LANGUAGE_KEY) || "nl-BE";
let activeCurrency = localStorage.getItem(CURRENCY_KEY) || "EUR";
let currencyFormatter = createCurrencyFormatter();
let percentFormatter = createPercentFormatter();

const els = {
  yearSelect: document.querySelector("#yearSelect"),
  targetRange: document.querySelector("#targetRange"),
  targetOutput: document.querySelector("#targetOutput"),
  totalIncome: document.querySelector("#totalIncome"),
  totalExpense: document.querySelector("#totalExpense"),
  totalBalance: document.querySelector("#totalBalance"),
  savingRate: document.querySelector("#savingRate"),
  incomeTrend: document.querySelector("#incomeTrend"),
  expenseTrend: document.querySelector("#expenseTrend"),
  balanceTrend: document.querySelector("#balanceTrend"),
  savingStatus: document.querySelector("#savingStatus"),
  chart: document.querySelector("#cashflowChart"),
  monthDetailChart: document.querySelector("#monthDetailChart"),
  categoryBars: document.querySelector("#categoryBars"),
  categoryForm: document.querySelector("#categoryForm"),
  newCategory: document.querySelector("#newCategory"),
  categoryList: document.querySelector("#categoryList"),
  openCategoryModal: document.querySelector("#openCategoryModal"),
  openEntryModal: document.querySelector("#openEntryModal"),
  appModal: document.querySelector("#appModal"),
  modalEyebrow: document.querySelector("#modalEyebrow"),
  modalTitle: document.querySelector("#modalTitle"),
  modalClose: document.querySelector("#modalClose"),
  categoryModalSection: document.querySelector("#categoryModalSection"),
  entryModalSection: document.querySelector("#entryModalSection"),
  monthRows: document.querySelector("#monthRows"),
  transactionRows: document.querySelector("#transactionRows"),
  detailTitle: document.querySelector("#detailTitle"),
  detailChartTitle: document.querySelector("#detailChartTitle"),
  bestMonth: document.querySelector("#bestMonth"),
  bestMonthCopy: document.querySelector("#bestMonthCopy"),
  scoreRingValue: document.querySelector("#scoreRingValue"),
  entryForm: document.querySelector("#entryForm"),
  entryMonth: document.querySelector("#entryMonth"),
  entryEndMonth: document.querySelector("#entryEndMonth"),
  entryType: document.querySelector("#entryType"),
  entryCategory: document.querySelector("#entryCategory"),
  entryAmount: document.querySelector("#entryAmount"),
  entryNote: document.querySelector("#entryNote"),
  themeToggle: document.querySelector("#themeToggle"),
  themeSettings: document.querySelector("#themeSettings"),
  appSettingsToggle: document.querySelector("#appSettingsToggle"),
  appSettings: document.querySelector("#appSettings"),
  accentColor: document.querySelector("#accentColor"),
  secondaryAccentColor: document.querySelector("#secondaryAccentColor"),
  backgroundColor: document.querySelector("#backgroundColor"),
  textColor: document.querySelector("#textColor"),
  buttonTextColor: document.querySelector("#buttonTextColor"),
  fontSelect: document.querySelector("#fontSelect"),
  languageSelect: document.querySelector("#languageSelect"),
  currencySelect: document.querySelector("#currencySelect"),
  restoreBackup: document.querySelector("#restoreBackup"),
  backupStatus: document.querySelector("#backupStatus"),
  appVersionLabel: document.querySelector("#appVersionLabel"),
  appVersion: document.querySelector("#appVersion"),
  updateNotice: document.querySelector("#updateNotice"),
  updateNoticeTitle: document.querySelector("#updateNoticeTitle"),
  updateNoticeBody: document.querySelector("#updateNoticeBody"),
  updateButton: document.querySelector("#updateButton"),
  toast: document.querySelector("#toast"),
  toastTitle: document.querySelector("#toastTitle"),
  toastBody: document.querySelector("#toastBody"),
  exportCsv: document.querySelector("#exportCsv"),
  resetData: document.querySelector("#resetData"),
};

applyAccentColor(localStorage.getItem(THEME_KEY) || els.accentColor.value);
applySecondaryAccentColor(localStorage.getItem(SECONDARY_ACCENT_KEY) || els.secondaryAccentColor.value);
applyBackgroundColor(localStorage.getItem(BACKGROUND_KEY) || els.backgroundColor.value);
applyTextColor(localStorage.getItem(TEXT_KEY) || els.textColor.value);
applyButtonTextColor(localStorage.getItem(BUTTON_TEXT_KEY) || els.buttonTextColor.value);
applyFont(localStorage.getItem(FONT_KEY) || els.fontSelect.value);
applySavingTarget(localStorage.getItem(SAVING_TARGET_KEY) || els.targetRange.value);
applyLocaleSettings(activeLocale, activeCurrency);

function createEmptyData() {
  return {
    [String(new Date().getFullYear())]: {
      categories: [...defaultCategories],
      entries: [],
    },
  };
}

function makeEntry(year, month, type, category, amount, note = "") {
  return {
    id: `${year}-${month}-${type}-${category}-${crypto.randomUUID()}`,
    month,
    type,
    category,
    amount: Number(amount),
    note: note.trim(),
  };
}

function loadData() {
  localStorage.removeItem("financeDashboardData");
  const saved = localStorage.getItem(STORAGE_KEY);
  return saved ? JSON.parse(saved) : structuredClone(defaultData);
}

function normalizeData(data) {
  const normalized = structuredClone(data);
  Object.entries(normalized).forEach(([year, yearData]) => {
    if (!Array.isArray(yearData.entries)) {
      normalized[year] = { categories: [], entries: [] };
      return;
    }
    yearData.entries = yearData.entries.map((entry, index) => ({
      id: entry.id || `${year}-legacy-${index}-${crypto.randomUUID()}`,
      month: Number(entry.month),
      type: entry.type === "expense" ? "expense" : "income",
      category: entry.category || (entry.type === "expense" ? "Overig" : "Salaris"),
      amount: Number(entry.amount) || 0,
      note: entry.note || "",
    }));
    const categories = new Set(yearData.categories || []);
    yearData.entries.forEach((entry) => categories.add(entry.category));
    if (!categories.size) defaultCategories.forEach((category) => categories.add(category));
    normalized[year].categories = [...categories].sort((a, b) => a.localeCompare(b, "nl"));
  });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
  return normalized;
}

function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(financeData));
}

function compareVersions(current, latest) {
  const currentParts = String(current).replace(/^v/i, "").split(".").map(Number);
  const latestParts = String(latest).replace(/^v/i, "").split(".").map(Number);
  const length = Math.max(currentParts.length, latestParts.length);
  for (let index = 0; index < length; index += 1) {
    const currentValue = currentParts[index] || 0;
    const latestValue = latestParts[index] || 0;
    if (latestValue > currentValue) return 1;
    if (latestValue < currentValue) return -1;
  }
  return 0;
}

function manifestUrl() {
  return UPDATE_MANIFEST_URL;
}

function showToast(title, body) {
  els.toastTitle.textContent = title;
  els.toastBody.textContent = body;
  els.toast.hidden = false;
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => {
    els.toast.hidden = true;
  }, 8000);
}

function showUpdateAvailable(version) {
  availableUpdateVersion = version;
  const body = t("updateAvailableBody").replace("{version}", version);
  els.updateNotice.hidden = false;
  els.updateNoticeTitle.textContent = t("updateAvailable");
  els.updateNoticeBody.textContent = body;
  showToast(t("updateAvailable"), body);
}

function hideUpdateAvailable() {
  availableUpdateVersion = null;
  els.updateNotice.hidden = true;
  els.updateNoticeTitle.textContent = "";
  els.updateNoticeBody.textContent = "";
}

async function handleUpdateClick() {
  const command = ".\\update.bat";
  if (!window.confirm(t("updateInstructions"))) return;
  try {
    await navigator.clipboard.writeText(command);
    showToast(t("updateCommandCopied"), t("updateCommandCopiedBody"));
  } catch (error) {
    window.prompt(t("updateCommandPrompt"), command);
  }
}

async function checkForUpdates() {
  els.appVersionLabel.textContent = t("version");
  els.appVersion.textContent = `v${APP_VERSION}`;
  hideUpdateAvailable();
  const url = manifestUrl();
  if (!url) return;

  try {
    const response = await fetch(`${url}${url.includes("?") ? "&" : "?"}t=${Date.now()}`, { cache: "no-store" });
    if (!response.ok) {
      hideUpdateAvailable();
      return;
    }
    const manifest = await response.json();
    if (manifest.version && compareVersions(APP_VERSION, manifest.version) > 0) {
      showUpdateAvailable(manifest.version);
    } else {
      hideUpdateAvailable();
    }
  } catch (error) {
    // Update checks are optional; failing silently keeps local/offline use smooth.
    hideUpdateAvailable();
  }
}

function backupDateLabel(timestamp) {
  return new Intl.DateTimeFormat(activeLocale, {
    dateStyle: "short",
    timeStyle: "short",
  }).format(new Date(timestamp));
}

function readBackup() {
  const backup = localStorage.getItem(BACKUP_KEY);
  return backup ? JSON.parse(backup) : null;
}

function createBackup() {
  const backup = {
    createdAt: new Date().toISOString(),
    data: structuredClone(financeData),
  };
  localStorage.setItem(BACKUP_KEY, JSON.stringify(backup));
  return backup;
}

function updateBackupStatus(message = null) {
  const backup = readBackup();
  els.restoreBackup.disabled = !backup;
  if (message) {
    els.backupStatus.textContent = message;
    return;
  }
  els.backupStatus.textContent = backup
    ? t("backupAvailable").replace("{date}", backupDateLabel(backup.createdAt))
    : t("noBackup");
}

function createCurrencyFormatter() {
  return new Intl.NumberFormat(activeLocale, {
    style: "currency",
    currency: activeCurrency,
    maximumFractionDigits: 0,
  });
}

function createPercentFormatter() {
  return new Intl.NumberFormat(activeLocale, {
    style: "percent",
    maximumFractionDigits: 1,
  });
}

function money(value) {
  return currencyFormatter.format(value);
}

function formatPercent(value) {
  return percentFormatter.format(value);
}

function t(key) {
  return translations[activeLocale]?.[key] || translations["nl-BE"][key] || key;
}

function monthName(index, format = "long") {
  return new Intl.DateTimeFormat(activeLocale, { month: format }).format(new Date(2026, index, 1));
}

function categoryName(category) {
  return translations[activeLocale]?.categoryNames?.[category] || category;
}

function setText(selector, value) {
  const element = document.querySelector(selector);
  if (element) element.textContent = value;
}

function setPlaceholder(selector, value) {
  const element = document.querySelector(selector);
  if (element) element.placeholder = value;
}

function applyTranslations() {
  const navItems = document.querySelectorAll(".nav-item");
  [t("overview"), t("chart"), t("categories"), t("months")].forEach((label, index) => {
    if (navItems[index]) navItems[index].textContent = label;
  });

  const sideLabels = document.querySelectorAll(".side-panel .panel-label");
  if (sideLabels[0]) sideLabels[0].textContent = t("year");
  if (sideLabels[1]) sideLabels[1].textContent = t("savingTarget");

  els.themeToggle.querySelector("span:last-child").textContent = t("theme");
  els.themeToggle.title = t("theme");
  els.themeToggle.setAttribute("aria-label", t("theme"));
  els.appSettingsToggle.querySelector("span:last-child").textContent = t("settings");
  els.appSettingsToggle.title = t("settings");
  els.appSettingsToggle.setAttribute("aria-label", t("settings"));
  document.querySelector(".sidebar").setAttribute("aria-label", t("sidebarNavigation"));
  document.querySelector(".nav-list").setAttribute("aria-label", t("sections"));
  els.yearSelect.setAttribute("aria-label", t("selectYear"));
  document.querySelector("#overzicht").setAttribute("aria-label", t("metrics"));
  els.chart.setAttribute("aria-label", t("cashflowChartLabel"));
  els.monthDetailChart.setAttribute("aria-label", t("monthDetailChartLabel"));
  els.categoryList.setAttribute("aria-label", t("categoryList"));

  const themeLabels = els.themeSettings.querySelectorAll("label");
  [t("accentColor"), t("secondaryAccentColor"), t("background"), t("textColor"), t("buttonText"), t("font")].forEach((label, index) => {
    const input = themeLabels[index]?.querySelector("input");
    const control = input || themeLabels[index]?.querySelector("select");
    if (themeLabels[index] && control) themeLabels[index].replaceChild(document.createTextNode(label), themeLabels[index].firstChild);
  });

  const appLabels = els.appSettings.querySelectorAll("label");
  [t("language"), t("currency")].forEach((label, index) => {
    const select = appLabels[index]?.querySelector("select");
    if (appLabels[index] && select) appLabels[index].replaceChild(document.createTextNode(label), appLabels[index].firstChild);
  });
  els.restoreBackup.textContent = t("restoreBackup");
  els.appVersionLabel.textContent = t("version");
  els.appVersion.textContent = `v${APP_VERSION}`;
  els.updateButton.textContent = t("updateAction");
  els.updateButton.title = t("updateAction");
  els.updateButton.setAttribute("aria-label", t("updateAction"));
  if (!els.updateNotice.hidden) {
    els.updateNoticeTitle.textContent = t("updateAvailable");
    if (availableUpdateVersion) {
      els.updateNoticeBody.textContent = t("updateAvailableBody").replace("{version}", availableUpdateVersion);
    }
  }

  setText(".topbar .eyebrow", t("yearlyMonthly"));
  setText(".topbar h2", t("incomeExpenseTitle"));
  els.exportCsv.title = t("exportCsv");
  els.exportCsv.setAttribute("aria-label", t("exportCsv"));
  els.resetData.title = t("deleteAll");
  els.resetData.setAttribute("aria-label", t("deleteAll"));

  const metricLabels = document.querySelectorAll(".metric p");
  [t("income"), t("expense"), t("balance"), t("savingRate")].forEach((label, index) => {
    if (metricLabels[index]) metricLabels[index].textContent = label;
  });

  setText(".trend-panel .eyebrow", t("trend"));
  setText(".trend-panel h3", t("monthlyCashflow"));
  const legendItems = document.querySelectorAll(".legend span");
  [t("income"), t("expense"), t("balance")].forEach((label, index) => {
    if (legendItems[index]) legendItems[index].lastChild.textContent = label;
  });
  setText(".distribution-panel .eyebrow", t("distribution"));
  setText(".distribution-panel h3", t("expenseMix"));

  setText(".best-month-summary .eyebrow", t("bestMonth"));
  setText(".month-chart-card .eyebrow", t("monthChart"));

  const actionsPanel = document.querySelector(".actions-panel");
  actionsPanel.querySelector(".eyebrow").textContent = t("actions");
  actionsPanel.querySelector("h3").textContent = t("actionsManage");
  els.openCategoryModal.querySelector("span:last-child").textContent = t("manageCategories");
  els.openEntryModal.querySelector("span:last-child").textContent = t("addTransaction");
  els.openCategoryModal.title = t("manageCategories");
  els.openEntryModal.title = t("addTransaction");
  els.openCategoryModal.setAttribute("aria-label", t("manageCategories"));
  els.openEntryModal.setAttribute("aria-label", t("addTransaction"));
  els.modalClose.title = t("cancel");
  els.modalClose.setAttribute("aria-label", t("cancel"));
  els.categoryModalSection.querySelector("label").firstChild.textContent = t("newCategory");
  const categoryButton = els.categoryModalSection.querySelector(".primary-button");
  categoryButton.textContent = "+";
  categoryButton.title = t("add");
  categoryButton.setAttribute("aria-label", t("add"));
  setPlaceholder("#newCategory", t("newCategoryPlaceholder"));

  const entryLabels = els.entryModalSection.querySelectorAll("label");
  [t("fromMonth"), t("toMonth"), t("type"), t("category"), t("amount"), t("note")].forEach((label, index) => {
    if (entryLabels[index]) entryLabels[index].firstChild.textContent = label;
  });
  els.entryModalSection.querySelector(".primary-button").textContent = t("add");
  setPlaceholder("#entryNote", t("notePlaceholder"));

  setText("#maanden .eyebrow", t("detail"));
  setText("#maanden h3", t("monthOverview"));
  const monthHeaders = document.querySelectorAll("#maanden th");
  [t("month"), t("income"), t("expense"), t("balance"), t("savingRate")].forEach((label, index) => {
    if (monthHeaders[index]) monthHeaders[index].textContent = label;
  });

  const detailPanel = els.transactionRows.closest(".table-panel");
  detailPanel.querySelector(".eyebrow").textContent = t("monthDetail");
  const detailHeaders = detailPanel.querySelectorAll("th");
  [t("type"), t("category"), t("note"), t("amount"), t("actions")].forEach((label, index) => {
    if (detailHeaders[index]) detailHeaders[index].textContent = label;
  });

  els.entryType.options[0].textContent = t("incomeType");
  els.entryType.options[1].textContent = t("expenseType");
  updateBackupStatus();
}

function applySavingTarget(value) {
  els.targetRange.value = value;
  els.targetOutput.textContent = `${value}%`;
  localStorage.setItem(SAVING_TARGET_KEY, value);
}

function applyLocaleSettings(locale, currency) {
  activeLocale = locale;
  activeCurrency = currency;
  currencyFormatter = createCurrencyFormatter();
  percentFormatter = createPercentFormatter();
  document.documentElement.lang = locale.slice(0, 2);
  els.languageSelect.value = locale;
  els.currencySelect.value = currency;
  localStorage.setItem(LANGUAGE_KEY, locale);
  localStorage.setItem(CURRENCY_KEY, currency);
}

function hexToRgb(hex) {
  const clean = hex.replace("#", "");
  const value = parseInt(clean.length === 3 ? clean.split("").map((char) => char + char).join("") : clean, 16);
  return {
    r: (value >> 16) & 255,
    g: (value >> 8) & 255,
    b: value & 255,
  };
}

function applyAccentColor(color) {
  const { r, g, b } = hexToRgb(color);
  document.documentElement.style.setProperty("--blue", color);
  document.documentElement.style.setProperty("--accent-rgb", `${r}, ${g}, ${b}`);
  els.accentColor.value = color;
  localStorage.setItem(THEME_KEY, color);
}

function applySecondaryAccentColor(color) {
  const { r, g, b } = hexToRgb(color);
  document.documentElement.style.setProperty("--blue-strong", color);
  document.documentElement.style.setProperty("--secondary-accent-rgb", `${r}, ${g}, ${b}`);
  els.secondaryAccentColor.value = color;
  localStorage.setItem(SECONDARY_ACCENT_KEY, color);
}

function clampColor(value) {
  return Math.max(0, Math.min(255, Math.round(value)));
}

function rgbToHex({ r, g, b }) {
  return `#${[r, g, b].map((value) => clampColor(value).toString(16).padStart(2, "0")).join("")}`;
}

function mixColor(color, target, amount) {
  return {
    r: color.r + (target.r - color.r) * amount,
    g: color.g + (target.g - color.g) * amount,
    b: color.b + (target.b - color.b) * amount,
  };
}

function luminance({ r, g, b }) {
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}

function applyBackgroundColor(color) {
  const base = hexToRgb(color);
  const surfaceTarget = luminance(base) > 0.65
    ? { r: 0, g: 0, b: 0 }
    : { r: 255, g: 255, b: 255 };
  const panel = mixColor(base, surfaceTarget, 0.07);
  const panel2 = mixColor(base, surfaceTarget, 0.12);

  document.documentElement.style.setProperty("--bg", color);
  document.documentElement.style.setProperty("--bg-rgb", `${base.r}, ${base.g}, ${base.b}`);
  document.documentElement.style.setProperty("--panel", rgbToHex(panel));
  document.documentElement.style.setProperty("--panel-rgb", `${clampColor(panel.r)}, ${clampColor(panel.g)}, ${clampColor(panel.b)}`);
  document.documentElement.style.setProperty("--panel-2", rgbToHex(panel2));
  document.documentElement.style.setProperty("--panel-2-rgb", `${clampColor(panel2.r)}, ${clampColor(panel2.g)}, ${clampColor(panel2.b)}`);
  els.backgroundColor.value = color;
  localStorage.setItem(BACKGROUND_KEY, color);
  applyTextColor(els.textColor.value);
}

function applyTextColor(color) {
  const base = hexToRgb(color);
  const muted = mixColor(base, hexToRgb(els.backgroundColor.value || "#07111f"), 0.36);

  document.documentElement.style.setProperty("--text", color);
  document.documentElement.style.setProperty("--muted", rgbToHex(muted));
  document.documentElement.style.setProperty("--muted-rgb", `${clampColor(muted.r)}, ${clampColor(muted.g)}, ${clampColor(muted.b)}`);
  els.textColor.value = color;
  localStorage.setItem(TEXT_KEY, color);
}

function applyButtonTextColor(color) {
  document.documentElement.style.setProperty("--button-text", color);
  els.buttonTextColor.value = color;
  localStorage.setItem(BUTTON_TEXT_KEY, color);
}

function applyFont(fontName) {
  document.documentElement.style.setProperty(
    "--app-font",
    `"${fontName}", ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`
  );
  els.fontSelect.value = fontName;
  localStorage.setItem(FONT_KEY, fontName);
}

function sum(values) {
  return values.reduce((total, value) => total + value, 0);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[char]);
}

function yearData() {
  return financeData[activeYear];
}

function monthlyTotals(data = yearData()) {
  const income = Array(12).fill(0);
  const expenses = Array(12).fill(0);
  data.entries.forEach((entry) => {
    if (entry.type === "income") income[entry.month] += entry.amount;
    else expenses[entry.month] += entry.amount;
  });
  return { income, expenses };
}

function expenseCategories(data = yearData()) {
  return data.entries.reduce((result, entry) => {
    if (entry.type === "expense") result[entry.category] = (result[entry.category] || 0) + entry.amount;
    return result;
  }, {});
}

function previousYearData() {
  const years = Object.keys(financeData).sort();
  const index = years.indexOf(activeYear);
  return index > 0 ? financeData[years[index - 1]] : null;
}

function trend(current, previous, inverse = false) {
  if (!previous) return { text: t("newYear"), negative: false };
  const change = previous === 0 ? 0 : (current - previous) / previous;
  const negative = inverse ? change > 0 : change < 0;
  const sign = change > 0 ? "+" : "";
  return { text: `${sign}${formatPercent(change)}`, negative };
}

function setTrend(element, value) {
  element.textContent = value.text;
  element.classList.toggle("negative", value.negative);
}

function renderSelectors() {
  els.yearSelect.innerHTML = Object.keys(financeData)
    .sort()
    .map((year) => `<option value="${year}">${year}</option>`)
    .join("");
  els.yearSelect.value = activeYear;

  els.entryMonth.innerHTML = months
    .map((month, index) => `<option value="${index}">${monthName(index)}</option>`)
    .join("");
  els.entryEndMonth.innerHTML = els.entryMonth.innerHTML;
  els.entryEndMonth.value = els.entryMonth.value || "0";

  els.entryCategory.innerHTML = yearData().categories
    .map((category) => `<option value="${escapeHtml(category)}">${escapeHtml(categoryName(category))}</option>`)
    .join("");
}

function monthOptions(selectedValue) {
  return months
    .map((month, index) => `<option value="${index}" ${Number(selectedValue) === index ? "selected" : ""}>${monthName(index)}</option>`)
    .join("");
}

function sameTransaction(a, b) {
  return (
    a.type === b.type &&
    a.category === b.category &&
    Number(a.amount) === Number(b.amount) &&
    (a.note || "") === (b.note || "")
  );
}

function removeMatchingTransactions(originalEntry, fromMonth, toMonth) {
  const from = Math.min(fromMonth, toMonth);
  const to = Math.max(fromMonth, toMonth);
  const removedIds = new Set();

  financeData[activeYear].entries = yearData().entries.filter((item) => {
    const shouldRemove = sameTransaction(item, originalEntry) && item.month >= from && item.month <= to;
    if (shouldRemove) removedIds.add(item.id);
    return !shouldRemove;
  });

  return removedIds;
}

function renderMetrics() {
  const totals = monthlyTotals();
  const previous = previousYearData();
  const previousTotals = previous ? monthlyTotals(previous) : null;
  const income = sum(totals.income);
  const expense = sum(totals.expenses);
  const balance = income - expense;
  const rate = income ? balance / income : 0;
  const target = Number(els.targetRange.value) / 100;

  els.totalIncome.textContent = money(income);
  els.totalExpense.textContent = money(expense);
  els.totalBalance.textContent = money(balance);
  els.savingRate.textContent = formatPercent(rate);
  els.savingStatus.textContent = rate >= target ? t("aboveTarget") : t("belowTarget");
  els.savingStatus.classList.toggle("negative", rate < target);

  setTrend(els.incomeTrend, trend(income, previousTotals ? sum(previousTotals.income) : null));
  setTrend(els.expenseTrend, trend(expense, previousTotals ? sum(previousTotals.expenses) : null, true));
  setTrend(els.balanceTrend, trend(balance, previousTotals ? sum(previousTotals.income) - sum(previousTotals.expenses) : null));
}

function setupCanvas(canvas) {
  const ratio = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.floor(rect.width * ratio);
  canvas.height = Math.floor(rect.height * ratio);
  const ctx = canvas.getContext("2d");
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  return { ctx, width: rect.width, height: rect.height };
}

function drawRoundedRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, Math.abs(height) / 2, width / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
  ctx.fill();
}

function drawChart() {
  const { ctx, width, height } = setupCanvas(els.chart);
  const accent = getComputedStyle(document.documentElement).getPropertyValue("--blue").trim() || "#38bdf8";
  const mutedRgb = getComputedStyle(document.documentElement).getPropertyValue("--muted-rgb").trim() || "159, 177, 199";
  const totals = monthlyTotals();
  const balances = totals.income.map((value, index) => value - totals.expenses[index]);
  const maxValue = Math.max(1, ...totals.income, ...totals.expenses, ...balances) * 1.14;
  const padding = { top: 28, right: 20, bottom: 44, left: 58 };
  const plotW = width - padding.left - padding.right;
  const plotH = height - padding.top - padding.bottom;
  const baseY = padding.top + plotH;
  const groupW = plotW / months.length;
  const barW = Math.max(7, Math.min(18, groupW * 0.22));

  ctx.clearRect(0, 0, width, height);
  ctx.font = "12px Inter, system-ui, sans-serif";
  ctx.lineWidth = 1;

  for (let i = 0; i <= 4; i += 1) {
    const y = padding.top + (plotH / 4) * i;
    const value = maxValue - (maxValue / 4) * i;
    ctx.strokeStyle = `rgba(${mutedRgb}, 0.14)`;
    ctx.beginPath();
    ctx.moveTo(padding.left, y);
    ctx.lineTo(width - padding.right, y);
    ctx.stroke();
    ctx.fillStyle = `rgba(${mutedRgb}, 0.8)`;
    ctx.fillText(money(value), 0, y + 4);
  }

  totals.income.forEach((income, index) => {
    const expense = totals.expenses[index];
    const x = padding.left + index * groupW + groupW / 2;
    const incomeH = (income / maxValue) * plotH;
    const expenseH = (expense / maxValue) * plotH;

    ctx.fillStyle = "#34d399";
    drawRoundedRect(ctx, x - barW - 2, baseY - incomeH, barW, incomeH, 5);
    ctx.fillStyle = "#fb7185";
    drawRoundedRect(ctx, x + 2, baseY - expenseH, barW, expenseH, 5);

    ctx.fillStyle = `rgba(${mutedRgb}, 0.82)`;
    ctx.textAlign = "center";
    ctx.fillText(monthName(index, "short"), x, height - 16);
  });

  ctx.beginPath();
  balances.forEach((balance, index) => {
    const x = padding.left + index * groupW + groupW / 2;
    const y = baseY - (balance / maxValue) * plotH;
    if (index === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.strokeStyle = accent;
  ctx.lineWidth = 3;
  ctx.stroke();

  balances.forEach((balance, index) => {
    const x = padding.left + index * groupW + groupW / 2;
    const y = baseY - (balance / maxValue) * plotH;
    ctx.fillStyle = "#06101e";
    ctx.beginPath();
    ctx.arc(x, y, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 2;
    ctx.stroke();
  });
}

function drawMonthDetailChart(entries) {
  const { ctx, width, height } = setupCanvas(els.monthDetailChart);
  const mutedRgb = getComputedStyle(document.documentElement).getPropertyValue("--muted-rgb").trim() || "159, 177, 199";
  const textColor = getComputedStyle(document.documentElement).getPropertyValue("--text").trim() || "#edf4ff";
  const bgColor = getComputedStyle(document.documentElement).getPropertyValue("--panel").trim() || "#0d1a2e";
  const groupedEntries = monthChartGroups(entries);
  const maxAbs = Math.max(1, ...groupedEntries.map((entry) => Math.abs(entry.signedAmount)));
  const padding = { top: 22, right: 18, bottom: 64, left: 58 };
  const plotW = width - padding.left - padding.right;
  const plotH = height - padding.top - padding.bottom;
  const zeroY = padding.top + plotH / 2;
  const barSlot = groupedEntries.length ? plotW / groupedEntries.length : plotW;
  const barW = Math.max(16, Math.min(44, barSlot * 0.5));

  ctx.clearRect(0, 0, width, height);
  ctx.font = "12px Inter, system-ui, sans-serif";

  ctx.strokeStyle = `rgba(${mutedRgb}, 0.18)`;
  ctx.beginPath();
  ctx.moveTo(padding.left, zeroY);
  ctx.lineTo(width - padding.right, zeroY);
  ctx.stroke();

  ctx.fillStyle = `rgba(${mutedRgb}, 0.78)`;
  ctx.textAlign = "right";
  ctx.fillText(money(maxAbs), padding.left - 10, padding.top + 6);
  ctx.fillText("0", padding.left - 10, zeroY + 4);
  ctx.fillText(money(-maxAbs), padding.left - 10, padding.top + plotH + 4);

  if (!groupedEntries.length) {
    ctx.fillStyle = `rgba(${mutedRgb}, 0.78)`;
    ctx.textAlign = "center";
    ctx.fillText(t("noTransactionsChart"), width / 2, height / 2);
    return;
  }

  groupedEntries.forEach((entry, index) => {
    const x = padding.left + index * barSlot + barSlot / 2;
    const barH = (Math.abs(entry.signedAmount) / maxAbs) * (plotH / 2 - 12);
    const y = entry.signedAmount >= 0 ? zeroY - barH : zeroY;
    const fill = entry.type === "income" ? "#34d399" : "#fb7185";

    ctx.fillStyle = fill;
    drawRoundedRect(ctx, x - barW / 2, y, barW, barH, 6);

    ctx.fillStyle = textColor;
    ctx.textAlign = "center";
    ctx.fillText(money(Math.abs(entry.signedAmount)), x, entry.signedAmount >= 0 ? y - 7 : y + barH + 16);

    drawMonthChartLabel(ctx, entry, x, height - 34, Math.max(54, barSlot - 8), mutedRgb);
  });

  ctx.fillStyle = bgColor;
}

function monthChartGroups(entries) {
  const groups = new Map();

  entries.forEach((entry) => {
    const note = (entry.note || "").trim();
    const key = [entry.type, entry.category, note].join("|");
    const signedAmount = entry.type === "income" ? entry.amount : -entry.amount;

    if (!groups.has(key)) {
      groups.set(key, {
        type: entry.type,
        category: entry.category,
        note,
        signedAmount: 0,
      });
    }
    groups.get(key).signedAmount += signedAmount;
  });

  return [...groups.values()].sort(
    (a, b) =>
      a.type.localeCompare(b.type) ||
      categoryName(a.category).localeCompare(categoryName(b.category), activeLocale) ||
      a.note.localeCompare(b.note, activeLocale)
  );
}

function fitCanvasText(ctx, text, maxWidth) {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let clipped = text;
  while (clipped.length > 1 && ctx.measureText(`${clipped}...`).width > maxWidth) {
    clipped = clipped.slice(0, -1);
  }
  return `${clipped}...`;
}

function drawMonthChartLabel(ctx, entry, x, y, maxWidth, mutedRgb) {
  const primary = entry.note || categoryName(entry.category);
  const secondary = entry.note ? categoryName(entry.category) : "";

  ctx.fillStyle = `rgba(${mutedRgb}, 0.95)`;
  ctx.textAlign = "center";
  ctx.font = "11px Inter, system-ui, sans-serif";
  ctx.fillText(fitCanvasText(ctx, primary, maxWidth), x, y);

  if (secondary) {
    ctx.fillStyle = `rgba(${mutedRgb}, 0.68)`;
    ctx.font = "10px Inter, system-ui, sans-serif";
    ctx.fillText(fitCanvasText(ctx, secondary, maxWidth), x, y + 14);
  }
}

function renderCategories() {
  const categories = expenseCategories();
  const max = Math.max(1, ...Object.values(categories));
  els.categoryBars.innerHTML = Object.entries(categories)
    .sort((a, b) => b[1] - a[1])
    .map(([name, value]) => {
      const width = Math.max(4, (value / max) * 100);
      return `
        <div class="category-row">
          <div class="category-meta">
            <span>${escapeHtml(categoryName(name))}</span>
            <strong>${money(value)}</strong>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width: ${width}%"></div></div>
        </div>
      `;
    })
    .join("");

  els.categoryList.innerHTML = yearData().categories
    .map((category) => `
      ${activeCategory === category ? renderActiveCategory(category) : `
        <button class="category-pill" type="button" data-category="${escapeHtml(category)}">${escapeHtml(categoryName(category))}</button>
      `}
    `)
    .join("");
}

function renderActiveCategory(category) {
  return `
    <div class="category-edit-row active-category" data-category="${escapeHtml(category)}">
      <input class="category-name-input" type="text" value="${escapeHtml(category)}" aria-label="${t("editCategoryName").replace("{category}", escapeHtml(categoryName(category)))}">
      <button class="mini-button icon-only save-category" type="button" aria-label="${t("saveCategory")}" title="${t("save")}">&#10003;</button>
      <button class="mini-button icon-only cancel-category" type="button" aria-label="${t("cancel")}" title="${t("cancel")}">&#8634;</button>
      <button class="mini-button icon-only danger delete-category" type="button" aria-label="${t("deleteCategory")}" title="${t("deleteCategory")}">&#128465;</button>
    </div>
  `;
}

function renderTableAndBestMonth() {
  const data = yearData();
  const totals = monthlyTotals();
  const balances = totals.income.map((value, index) => value - totals.expenses[index]);
  const bestBalance = Math.max(...balances);
  const bestIndex = balances.indexOf(bestBalance);

  els.monthRows.innerHTML = months
    .map((month, index) => {
      const income = totals.income[index];
      const expense = totals.expenses[index];
      const balance = income - expense;
      const rate = income ? balance / income : 0;
      return `
        <tr class="month-summary-row ${selectedMonth === index ? "selected-row" : ""}" data-month="${index}">
          <td><button class="text-button select-month" type="button">${monthName(index)}</button></td>
          <td>${money(income)}</td>
          <td>${money(expense)}</td>
          <td class="${balance >= 0 ? "positive" : "negative-text"}">${money(balance)}</td>
          <td>${formatPercent(rate)}</td>
        </tr>
      `;
    })
    .join("");

  const yearlyIncome = sum(totals.income);
  const yearlyBalance = yearlyIncome - sum(totals.expenses);
  const score = yearlyIncome ? Math.max(0, Math.min(100, (yearlyBalance / yearlyIncome) * 100)) : 0;
  const bestMonthName = Number.isInteger(bestIndex) && bestIndex >= 0 ? monthName(bestIndex) : "-";
  els.bestMonth.textContent = bestMonthName;
  els.bestMonthCopy.textContent = t("bestMonthCopy")
    .replace("{month}", bestMonthName)
    .replace("{amount}", money(bestBalance || 0));
  els.scoreRingValue.textContent = `${Math.round(score)}%`;
  renderTransactionDetails();
}

function renderTransactionDetails(editingId = null, deletingId = null) {
  const entries = yearData().entries
    .filter((entry) => entry.month === selectedMonth)
    .slice()
    .sort((a, b) => a.type.localeCompare(b.type) || a.category.localeCompare(b.category, "nl"));

  els.detailTitle.textContent = monthName(selectedMonth);
  els.detailChartTitle.textContent = monthName(selectedMonth);
  drawMonthDetailChart(entries);
  els.transactionRows.innerHTML = entries.length
    ? entries.map((entry) => renderTransactionRow(entry, editingId === entry.id, deletingId === entry.id)).join("")
    : `<tr><td colspan="5" class="empty-cell">${t("noTransactions")}</td></tr>`;
}

function renderTransactionRow(entry, isEditing, isDeleting) {
  if (isDeleting) {
    return `
      <tr data-id="${entry.id}">
        <td colspan="5">
          <div class="detail-edit-grid delete-period-row">
            <div>
              <span class="muted">${t("deletePeriod")}</span>
              <strong>${entry.type === "income" ? t("incomeType") : t("expenseType")} - ${escapeHtml(categoryName(entry.category))}</strong>
              <small>${escapeHtml(t("deletePeriodHint"))}</small>
            </div>
            <label>
              ${t("fromMonth")}
              <select class="detail-input" data-field="deleteFromMonth">${monthOptions(entry.month)}</select>
            </label>
            <label>
              ${t("toMonth")}
              <select class="detail-input" data-field="deleteToMonth">${monthOptions(entry.month)}</select>
            </label>
            <div class="row-actions">
              <button class="mini-button icon-only danger confirm-delete-entry" type="button" aria-label="${t("deletePeriod")}" title="${t("deletePeriod")}">&#128465;</button>
              <button class="mini-button icon-only cancel-entry" type="button" aria-label="${t("cancel")}" title="${t("cancel")}">&#8634;</button>
            </div>
          </div>
        </td>
      </tr>
    `;
  }

  if (!isEditing) {
    return `
      <tr data-id="${entry.id}">
        <td>${entry.type === "income" ? t("incomeType") : t("expenseType")}</td>
        <td>${escapeHtml(categoryName(entry.category))}</td>
        <td class="note-cell">${entry.note ? escapeHtml(entry.note) : "<span class=\"muted\">-</span>"}</td>
        <td>${money(entry.amount)}</td>
        <td>
          <div class="row-actions">
            <button class="mini-button icon-only edit-entry" type="button" aria-label="${t("editTransaction")}" title="${t("editTransaction")}">&#9998;</button>
            <button class="mini-button icon-only danger delete-entry" type="button" aria-label="${t("deleteTransaction")}" title="${t("deleteTransaction")}">&#128465;</button>
          </div>
        </td>
      </tr>
    `;
  }

  const categories = yearData().categories
    .map((category) => `<option value="${escapeHtml(category)}" ${entry.category === category ? "selected" : ""}>${escapeHtml(categoryName(category))}</option>`)
    .join("");

  return `
    <tr data-id="${entry.id}">
      <td colspan="5">
        <div class="detail-edit-grid">
          <label>
            ${t("fromMonth")}
            <select class="detail-input" data-field="fromMonth">${monthOptions(entry.month)}</select>
          </label>
          <label>
            ${t("toMonth")}
            <select class="detail-input" data-field="toMonth">${monthOptions(entry.month)}</select>
          </label>
          <label>
            ${t("type")}
            <select class="detail-input" data-field="type">
              <option value="income" ${entry.type === "income" ? "selected" : ""}>${t("incomeType")}</option>
              <option value="expense" ${entry.type === "expense" ? "selected" : ""}>${t("expenseType")}</option>
            </select>
          </label>
          <label>
            ${t("category")}
            <select class="detail-input" data-field="category">${categories}</select>
          </label>
          <label>
            ${t("note")}
            <input class="detail-input note-input" data-field="note" type="text" value="${escapeHtml(entry.note)}" placeholder="${t("notePlaceholder")}">
          </label>
          <label>
            ${t("amount")}
            <input class="detail-input amount-input" data-field="amount" type="number" min="0" step="0.01" value="${entry.amount}">
          </label>
          <div class="row-actions">
            <button class="mini-button icon-only save-entry" type="button" aria-label="${t("saveTransaction")}" title="${t("save")}">&#10003;</button>
            <button class="mini-button icon-only cancel-entry" type="button" aria-label="${t("cancel")}" title="${t("cancel")}">&#8634;</button>
          </div>
        </div>
      </td>
    </tr>
  `;
}

function renderAll() {
  applyTranslations();
  renderSelectors();
  renderMetrics();
  drawChart();
  renderCategories();
  renderTableAndBestMonth();
}

function exportCsv() {
  const rows = [["Jaar", "Maand", "Type", "Categorie", "Notitie", "Bedrag"]];
  yearData().entries
    .slice()
    .sort((a, b) => a.month - b.month)
    .forEach((entry) => {
      rows.push([activeYear, monthName(entry.month), entry.type === "income" ? t("incomeType") : t("expenseType"), entry.category, entry.note || "", entry.amount]);
    });
  const csv = rows.map((row) => row.join(";")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `inkomsten-uitgaven-${activeYear}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

function findEntry(id) {
  return yearData().entries.find((entry) => entry.id === id);
}

function openModal(mode) {
  const isCategoryMode = mode === "categories";
  els.appModal.hidden = false;
  els.appModal.dataset.mode = mode;
  els.modalEyebrow.textContent = t("actions");
  els.modalTitle.textContent = isCategoryMode ? t("manageCategories") : t("addTransaction");
  els.categoryModalSection.hidden = !isCategoryMode;
  els.entryModalSection.hidden = isCategoryMode;
  const firstControl = isCategoryMode ? els.newCategory : els.entryAmount;
  window.setTimeout(() => firstControl.focus(), 0);
}

function closeModal() {
  els.appModal.hidden = true;
  els.categoryModalSection.hidden = true;
  els.entryModalSection.hidden = true;
  activeCategory = null;
  renderCategories();
}

els.yearSelect.addEventListener("change", (event) => {
  activeYear = event.target.value;
  selectedMonth = Math.min(selectedMonth, 11);
  renderAll();
});

els.targetRange.addEventListener("input", (event) => {
  applySavingTarget(event.target.value);
  renderMetrics();
});

els.themeToggle.addEventListener("click", () => {
  const isOpen = !els.themeSettings.hidden;
  els.themeSettings.hidden = isOpen;
  els.themeToggle.setAttribute("aria-expanded", String(!isOpen));
});

els.appSettingsToggle.addEventListener("click", () => {
  const isOpen = !els.appSettings.hidden;
  els.appSettings.hidden = isOpen;
  els.appSettingsToggle.setAttribute("aria-expanded", String(!isOpen));
});

els.languageSelect.addEventListener("change", (event) => {
  applyLocaleSettings(event.target.value, activeCurrency);
  renderAll();
});

els.currencySelect.addEventListener("change", (event) => {
  applyLocaleSettings(activeLocale, event.target.value);
  renderAll();
});

els.restoreBackup.addEventListener("click", () => {
  const backup = readBackup();
  if (!backup || !window.confirm(t("confirmRestoreBackup"))) return;
  financeData = normalizeData(backup.data);
  activeYear = Object.keys(financeData).sort().at(-1);
  selectedMonth = Math.min(selectedMonth, 11);
  saveData();
  renderAll();
  updateBackupStatus(t("backupRestored"));
});

els.updateButton.addEventListener("click", handleUpdateClick);

els.openCategoryModal.addEventListener("click", () => openModal("categories"));

els.openEntryModal.addEventListener("click", () => openModal("entry"));

els.modalClose.addEventListener("click", closeModal);

els.appModal.addEventListener("click", (event) => {
  if (event.target === els.appModal) closeModal();
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !els.appModal.hidden) closeModal();
});

els.accentColor.addEventListener("input", (event) => {
  applyAccentColor(event.target.value);
  drawChart();
});

els.secondaryAccentColor.addEventListener("input", (event) => {
  applySecondaryAccentColor(event.target.value);
});

els.backgroundColor.addEventListener("input", (event) => {
  applyBackgroundColor(event.target.value);
  drawChart();
});

els.textColor.addEventListener("input", (event) => {
  applyTextColor(event.target.value);
  drawChart();
});

els.buttonTextColor.addEventListener("input", (event) => {
  applyButtonTextColor(event.target.value);
});

els.fontSelect.addEventListener("change", (event) => {
  applyFont(event.target.value);
  drawChart();
  renderTransactionDetails();
});

els.entryMonth.addEventListener("change", () => {
  if (Number(els.entryEndMonth.value) < Number(els.entryMonth.value)) {
    els.entryEndMonth.value = els.entryMonth.value;
  }
});

els.categoryForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const category = els.newCategory.value.trim();
  if (!category) return;
  const categories = yearData().categories;
  if (!categories.some((item) => item.toLowerCase() === category.toLowerCase())) {
    categories.push(category);
    categories.sort((a, b) => a.localeCompare(b, "nl"));
    saveData();
  }
  els.categoryForm.reset();
  renderAll();
});

els.categoryList.addEventListener("click", (event) => {
  const pill = event.target.closest(".category-pill");
  if (pill) {
    activeCategory = pill.dataset.category;
    renderCategories();
    return;
  }

  const row = event.target.closest(".category-edit-row");
  if (!row) return;

  const oldCategory = row.dataset.category;
  const input = row.querySelector(".category-name-input");
  const newCategory = input.value.trim();
  const data = yearData();

  if (event.target.classList.contains("cancel-category")) {
    activeCategory = null;
    renderCategories();
    return;
  }

  if (event.target.classList.contains("save-category")) {
    if (!newCategory) return;
    const duplicate = data.categories.some(
      (category) => category.toLowerCase() === newCategory.toLowerCase() && category !== oldCategory
    );
    if (duplicate) {
      input.focus();
      return;
    }

    data.categories = data.categories
      .map((category) => (category === oldCategory ? newCategory : category))
      .sort((a, b) => a.localeCompare(b, "nl"));
    data.entries.forEach((entry) => {
      if (entry.category === oldCategory) entry.category = newCategory;
    });
    activeCategory = null;
    saveData();
    renderAll();
    return;
  }

  if (event.target.classList.contains("delete-category")) {
    data.categories = data.categories.filter((category) => category !== oldCategory);
    data.entries = data.entries.filter((entry) => entry.category !== oldCategory);
    if (!data.categories.length) data.categories.push("Overig");
    activeCategory = null;
    saveData();
    renderAll();
  }
});

els.entryForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const startMonth = Number(els.entryMonth.value);
  const endMonth = Number(els.entryEndMonth.value);
  const fromMonth = Math.min(startMonth, endMonth);
  const toMonth = Math.max(startMonth, endMonth);
  const amount = Number(els.entryAmount.value);
  const category = els.entryCategory.value;
  const note = els.entryNote.value.trim();
  if (!category || !Number.isFinite(amount)) return;

  for (let monthIndex = fromMonth; monthIndex <= toMonth; monthIndex += 1) {
    yearData().entries.push(makeEntry(activeYear, monthIndex, els.entryType.value, category, amount, note));
  }
  selectedMonth = fromMonth;
  saveData();
  els.entryForm.reset();
  renderAll();
});

els.monthRows.addEventListener("click", (event) => {
  const row = event.target.closest("tr[data-month]");
  if (!row) return;
  selectedMonth = Number(row.dataset.month);
  renderTableAndBestMonth();
});

els.transactionRows.addEventListener("click", (event) => {
  const row = event.target.closest("tr[data-id]");
  if (!row) return;
  const entry = findEntry(row.dataset.id);
  if (!entry) return;

  if (event.target.classList.contains("edit-entry")) {
    renderTransactionDetails(entry.id);
    return;
  }

  if (event.target.classList.contains("cancel-entry")) {
    renderTransactionDetails();
    return;
  }

  if (event.target.classList.contains("delete-entry")) {
    renderTransactionDetails(null, entry.id);
    return;
  }

  if (event.target.classList.contains("confirm-delete-entry")) {
    const fromMonth = Number(row.querySelector('[data-field="deleteFromMonth"]').value);
    const toMonth = Number(row.querySelector('[data-field="deleteToMonth"]').value);
    removeMatchingTransactions(entry, fromMonth, toMonth);
    saveData();
    renderAll();
    return;
  }

  if (event.target.classList.contains("save-entry")) {
    const originalEntry = { ...entry };
    const fromMonth = Number(row.querySelector('[data-field="fromMonth"]').value);
    const toMonth = Number(row.querySelector('[data-field="toMonth"]').value);
    const from = Math.min(fromMonth, toMonth);
    const to = Math.max(fromMonth, toMonth);
    const nextEntry = {
      type: row.querySelector('[data-field="type"]').value,
      category: row.querySelector('[data-field="category"]').value,
      note: row.querySelector('[data-field="note"]').value.trim(),
      amount: Number(row.querySelector('[data-field="amount"]').value) || 0,
    };

    removeMatchingTransactions(originalEntry, from, to);
    for (let monthIndex = from; monthIndex <= to; monthIndex += 1) {
      yearData().entries.push(makeEntry(activeYear, monthIndex, nextEntry.type, nextEntry.category, nextEntry.amount, nextEntry.note));
    }
    selectedMonth = from;
    saveData();
    renderAll();
  }
});

els.exportCsv.addEventListener("click", exportCsv);

els.resetData.addEventListener("click", () => {
  if (!window.confirm(t("confirmReset"))) return;
  const backup = createBackup();
  financeData = structuredClone(defaultData);
  activeYear = Object.keys(financeData).sort().at(-1);
  localStorage.removeItem("financeDashboardData");
  saveData();
  renderAll();
  updateBackupStatus(t("backupCreated").replace("{date}", backupDateLabel(backup.createdAt)));
});

window.addEventListener("resize", () => {
  drawChart();
  renderTransactionDetails();
});

renderAll();
checkForUpdates();
